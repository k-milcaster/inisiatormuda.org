<footer>    
    <div class="container_12">
        <div class="grid_12">
            <div class="socials">
                <a href="#"></a>
                <a href="#"></a>
                <a href="#"></a>
                <a href="#"></a>
            </div>
            <div class="copy">
                InisiatorMuda (C) 2015 | <a href="#">Privacy Policy</a> | Website developed by <a href="#" rel="nofollow">K-Software Development</a><br>
            </div>
        </div>
    </div>
</footer>
</body>
</html>
