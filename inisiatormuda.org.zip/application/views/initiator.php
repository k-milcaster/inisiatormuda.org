<div class="content"><div class="ic"></div>
    <div class="container_12">
        <div class="grid_12">
            <h3 class="pb1"><span>Initiators</span></h3>
            <img style="max-height:248px;max-width:276px;" src="<?php echo base_url(); ?>public/images/aboutus/anbar.jpg" alt="" class="img_inner fleft hvr-grow">
            <div class="extra_wrapper">
                <p>Mertola fringilla nisi justo, et pulvinar metus eleifend vitae. Lsce quis orci commodom hendrerit quam quis, ullamcorper sem. Ferulla gravida quam sed vehicula suscipite. Proin non ligula ne. Mauris porttitor vitae purus et pretium. Mauris ut viverrar  amet tempus sapien.</p>
            </div>
            <div class="clearfix"></div>
            <br>            
            <img style="max-height:248px;max-width:276px;" src="<?php echo base_url(); ?>public/images/aboutus/aem.jpg" alt="" class="img_inner fright hvr-grow">
            <div class="extra_wrapper">
                <p align="right" style="padding-right: 15px;">Mertola fringilla nisi justo, et pulvinar metus eleifend vitae. Lsce quis orci commodom hendrerit quam quis, ullamcorper sem. Ferulla gravida quam sed vehicula suscipite. Proin non ligula ne. Mauris porttitor vitae purus et pretium. Mauris ut viverrar  amet tempus sapien.</p>
            </div>
            <div class="clearfix"></div>
            <br>            
            <img style="max-height:248px;max-width:276px;" src="<?php echo base_url(); ?>public/images/aboutus/della.jpg" alt="" class="img_inner fleft hvr-grow">
            <div class="extra_wrapper">
                <p>Mertola fringilla nisi justo, et pulvinar metus eleifend vitae. Lsce quis orci commodom hendrerit quam quis, ullamcorper sem. Ferulla gravida quam sed vehicula suscipite. Proin non ligula ne. Mauris porttitor vitae purus et pretium. Mauris ut viverrar  amet tempus sapien.</p>
            </div>
            <div class="clearfix"></div>
            <br>            
            <img style="max-height:248px;max-width:276px;" src="<?php echo base_url(); ?>public/images/aboutus/elsa.jpg" alt="" class="img_inner fright hvr-grow">
            <div class="extra_wrapper">
                <p align="right" style="padding-right: 15px;">Mertola fringilla nisi justo, et pulvinar metus eleifend vitae. Lsce quis orci commodom hendrerit quam quis, ullamcorper sem. Ferulla gravida quam sed vehicula suscipite. Proin non ligula ne. Mauris porttitor vitae purus et pretium. Mauris ut viverrar  amet tempus sapien.</p>
            </div>
            <div class="clearfix"></div>
            <br>            
            <img style="max-height:248px;max-width:276px;" src="<?php echo base_url(); ?>public/images/aboutus/oh.jpg" alt="" class="img_inner fleft hvr-grow">
            <div class="extra_wrapper">
                <p>Mertola fringilla nisi justo, et pulvinar metus eleifend vitae. Lsce quis orci commodom hendrerit quam quis, ullamcorper sem. Ferulla gravida quam sed vehicula suscipite. Proin non ligula ne. Mauris porttitor vitae purus et pretium. Mauris ut viverrar  amet tempus sapien.</p>
            </div>
            <div class="clearfix"></div>
            <br>            
            <img style="max-height:248px;max-width:276px;" src="<?php echo base_url(); ?>public/images/aboutus/ryand.jpg" alt="" class="img_inner fright hvr-grow">
            <div class="extra_wrapper">
                <p align="right" style="padding-right: 15px;">Mertola fringilla nisi justo, et pulvinar metus eleifend vitae. Lsce quis orci commodom hendrerit quam quis, ullamcorper sem. Ferulla gravida quam sed vehicula suscipite. Proin non ligula ne. Mauris porttitor vitae purus et pretium. Mauris ut viverrar  amet tempus sapien.</p>
            </div>
        </div>
    </div>
</div>