<div class="content"><div class="ic"></div>
    <div class="container_12">
        <div class="grid_12">
            <h3><span>Log In</span></h3></div>
        <div class="grid_6 prefix_1">
            <form id="form" method="post">               
                <fieldset>
                    <label class="name">
                        <input type="text" name="username" placeholder="Userame:" class="field">
                        <br class="error">
                        <span class="empty error-empty">*This field is required.</span> </label>
                    <label class="password">
                        <input type="password" name="password" placeholder="Password:" class="field">
                        <br class="clear">
                        <span class="empty error-empty">*This field is required.</span> </label>
                    <div class="clear"></div>
                    <div class="btns">
                        <input type="submit" name="login" value="logIn" class="btn-red-gundek">
                        <div class="clear"></div>
                    </div></fieldset></form>
            Marketing Department: <br>
            E-mail: <span class="col1"><a href="#">marketing@templatemonster.com</a></span> <br>
            Phone: 1-518-312-4162
        </div>
    </div>
</div>