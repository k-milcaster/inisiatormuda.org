<div class="content"><div class="ic"></div>
    <div class="container_12">
        <div class="grid_12">
            <h3 class="pb1"><span>clients list</span></h3>
            <img src="public/images/page4_img1.jpg" alt="" class="img_inner fleft">
            <div class="extra_wrapper">
                <p>Mertola fringilla nisi justo, et pulvinar metus eleifend vitae. Lsce quis orci commodom hendrerit quam quis, ullamcorper sem. Ferulla gravida quam sed vehicula suscipite. Proin non ligula ne. Mauris porttitor vitae purus et pretium. Mauris ut viverrar  amet tempus sapien.</p>
                <ul class="list1 l1">
                    <li><a href="#">Dertoc quis fermentuemp coetum retomy</a></li>
                    <li><a href="#">Gaeorem ipsu dolor sit ametnsecteture </a></li>
                    <li><a href="#">Bewn mollis erat mattis neque facilisis sit  </a></li>
                    <li><a href="#">Vedas facilisis nullam velk viverra auc</a></li>
                </ul>
                <ul class="list1 l1">
                    <li><a href="#">Bertoce quis fermentuempus coetum reto</a></li>
                    <li><a href="#">Lorem ipsum dolor sit amet, consectetur </a></li>
                    <li><a href="#">In mollis erat mattis neque facilisis sit ame </a></li>
                    <li><a href="#">Cras facilisis, nulla vel viverra auctorle </a></li>
                </ul>
            </div>
        </div>
        <div class="clear"></div>
        <div class="grid_12">
            <h3 class="head3"><span>Be Our Client</span></h3>
        </div>
        <div class="grid_4">
            <div class="icon">
                <img src="public/images/icn1.png" alt="">
                <div class="title"><a href="#">Membership</a></div>Fusce quis fermentum nisl. Ut tempus cometum urna is sed feugiat. Cras pulvinar lorem sagi isallvestibulumnisi nec gravida maecenas sit amet eros conr, convallis.   
            </div>
        </div>
        <div class="grid_4">
            <div class="icon">
                <img src="public/images/icn2.png" alt="">
                <div class="title"><a href="#">Cooperation</a></div>Fusce quis fermentum nisl. Ut tempus cometum urna is sed feugiat. Cras pulvinar lorem sagi isallvestibulumnisi nec gravida maecenas sit amet eros conr, convallis.   
            </div>
        </div>
        <div class="grid_4">
            <div class="icon">
                <img src="public/images/icn3.png" alt="">
                <div class="title"><a href="#">Advantages</a></div>Fusce quis fermentum nisl. Ut tempus cometum urna is sed feugiat. Cras pulvinar lorem sagi isallvestibulumnisi nec gravida maecenas sit amet eros conr, convallis.   
            </div>
        </div>
        <div class="grid_12">
            <h3><span>Our Clients</span></h3>
        </div>
        <div class="clear"></div>
        <div class="logos">
            <div class="grid_4"><a href="#"><img src="public/images/page4_img2.jpg" alt=""></a></div>
            <div class="grid_4"><a href="#"><img src="public/images/page4_img3.jpg" alt=""></a></div>
            <div class="grid_4"><a href="#"><img src="public/images/page4_img4.jpg" alt=""></a></div>
        </div>
        <div class="grid_12">
            <p class="text1 col1"><a href="#">Vivamus at magna non nunc tristique rhoncus.</a></p>
            <p class="col3">Derto malice quis fermentum nisl tempus cometumylo. Geterna is sed nui feugiat. Cras pulvinar lorem sagi isallvestibulumnisi nec gravida merto urpis. In eget interdum dolor vermani lomito sanderilou. </p>
            Nulla fringilla nisi justo, et pulvinar metus eleifend vitae. Fusce quis orci commodom hendrerit quam quis, ullamcorper sem. Nulla gravida quam sed vehicula suscipite. Proin non ligula neque. Mauris porttitor vitae purus et pretium. Mauris ut viverrar  amet tempus sapien. Fusce dapibus ultrices purus nec auctor. Vivamus facilisis cibus dolor in aliquam. Maecenas ac sollicitudin dolor. In viverra ornare dapibus.
        </div>
    </div>
</div>