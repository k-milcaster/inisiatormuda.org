<div class="content"><div class="ic"></div>
    <div class="container_12">
        <div class="grid_6">
            <h3><span>Greetings From Executive Director</span></h3>
            <p class="col3">Derto malice quis fermentum nisl tempus cometumylo. Geterna is sed nui feugiat. Cras pulvinar lorem sagi isallvestibulumnisi nec gravida merto maecnasturpis. In eget interdum dolor vermani lomito sanderilou.</p>
            Nulla fringilla nisi justo, et pulvinar metus eleifend vitae. Fusce quis orci commodom hendrerit quam quis, ullamcorper sem. Nulla gravida quam sed vehicula suscipite. Proin non ligula neque. Mauris porttitor vitae purus et pretium. Mauris ut viverrar  amet tempus sapien. <br>
            <a href="#" class="btn">MORE</a>         
            <h3 class="head2"><span><a href="<?php echo base_url();?>about/initiator">Initiators</a></span></h3>
            <div class="team">
                <div class="grid_2">
                    <img src="<?php echo base_url(); ?>public/images/aboutus/anbar.jpg" alt="">
                    <div class="col3">Anbar Jayaedi</div>Rerna is sed feugiat cras pulvinar lorem. 
                </div>
                <div class="grid_2">
                    <img src="<?php echo base_url(); ?>public/images/aboutus/AEM.jpg" alt="">
                    <div class="col3">Aninta Ekalina</div>Rerna is sed feugiat cras pulvinar lorem. 
                </div>
                <div class="grid_2">
                    <img src="<?php echo base_url(); ?>public/images/aboutus/della.jpg" alt="">
                    <div class="col3">Della Sri</div>Rerna is sed feugiat cras pulvinar lorem. 
                </div>
                <div class="clear"></div>
                <div class="grid_2">
                    <img src="<?php echo base_url(); ?>public/images/aboutus/elsa.jpg" alt="">
                    <div class="col3">Elsa</div>Rerna is sed feugiat cras pulvinar lorem. 
                </div>
                <div class="grid_2">
                    <img src="<?php echo base_url(); ?>public/images/aboutus/oh.jpg" alt="">
                    <div class="col3">Ohyongyi</div>Rerna is sed feugiat cras pulvinar lorem. 
                </div>
                <div class="grid_2">
                    <img src="<?php echo base_url(); ?>public/images/aboutus/ryand.jpg" alt="">
                    <div class="col3">Ryand</div>Rerna is sed feugiat cras pulvinar lorem. 
                </div>
            </div>
        </div>
        <div class="grid_5 prefix_1">
            <h3 class="head1 h1">Board of Advisors</h3>
            <div class="team">
                <div class="grid_2">
                    <img src="<?php echo base_url(); ?>public/images/aboutus/damian.jpg" alt="">
                    <div class="col3"><a href="#">Damian</a></div>Rerna is sed feugiat cras pulvinar lorem. 
                </div>
            </div>
            <!--            <ul class="list1 col3">
                            <li><a href="#">Bertoce quis fermentuempus coetum reto</a></li>
                            <li><a href="#">Lorem ipsum dolor sit amet, consectetur</a></li>
                            <li><a href="#">In mollis erat mattis neque facilisis sit ame </a></li>
                            <li><a href="#">Cras facilisis, nulla vel viverra auctorle </a></li>
                            <li><a href="#">Proin pharetra luctus diam, a scelerisqu </a></li>
                            <li><a href="#">Aliquam nibh anterno mertilo neiner</a></li>
                            <li><a href="#">Etiam dui eros, laoreet sit amet aniloto me</a></li>
                        </ul>-->
            <h3 class="head1">Board of Directors</h3>
            <ul class="list">
                <li>
                    <div class="count">1</div>
                    <div class="extra_wrapper">
                        <div class="col3"><a href="#">Fusce quis fermentum nisl tempus comelo. </a></div>Rerna is sed feugiat. Cras pulvinar lorem sagi isallvestibulumnisi nec gravida. 
                    </div>
                </li>
                <li>
                    <div class="count">2</div>
                    <div class="extra_wrapper">
                        <div class="col3"><a href="#">Fusce quis fermentum nisl tempus ctumylo. </a></div>Rerna is sed feugiat. Cras pulvinar lorem sagi isallvestibulumnisi nec gravida. 
                    </div>
                </li>
                <li>
                    <div class="count">3</div>
                    <div class="extra_wrapper">
                        <div class="col3"><a href="#">Fusce quis fermentum nisl tempus coetumyl. </a></div>Rerna is sed feugiat. Cras pulvinar lorem sagi isallvestibulumnisi nec gravida. 
                    </div>
                </li>
            </ul>

        </div>

    </div>
</div>
