<div class="slider_wrapper">
    <div id="camera_wrap" class="">
       
        <div data-src="<?php echo base_url(); ?>public/images/slider/slide1.jpg">
            <div class="caption">
                <div class="slide-text-info">
                    <h1>RECENTLY POST</h1>    
                </div>
            </div>
        </div>
        <div data-src="<?php echo base_url(); ?>public/images/slider/slide2.jpg">
            <div class="caption">
                <div class="slide-text-info">
                    <h1>Judicial Review UU Perkawinan</h1>    
                </div>
            </div>
        </div>
    </div>
</div>
<!--==============================Content=================================-->

<div class="content"><div class="ic"></div>
    <div class="container_12">
        <div class="grid_12">
            <h2>CORE PROGRAMS<span>Beberapa program yang kami lakukan diantaranya </span></h2>
            <h3><span>Our Activity</span></h3>
        </div>
        <div class="grid_4">
            <div class="icon">
                <img src="<?php echo base_url(); ?>public/images/act/Edukasi.jpg" alt="" >
                <div class="title">EDUKASI</div>
            </div>
        </div>
        <div class="grid_4">
            <div class="icon">
                <img src="<?php echo base_url(); ?>public/images/act/Legal.jpg" alt="" >
                <div class="title">LEGAL</div></div>
        </div>
        <div class="grid_4">
            <div class="icon">
                <img src="<?php echo base_url(); ?>public/images/act/Riset.jpg" alt="" >
                <div class="title">RISET</div>
            </div>
        </div>
        <div class="grid_12">
            <h3><span>Media Coverage</span></h3>
        </div>
        <div class="clear"></div>
        <div class="works">
            <div class="grid_4"><a href="#"><img src="<?php echo base_url(); ?>public/images/liputan/Detik.jpg" alt=""></a></div>
            <div class="grid_4"><a href="#"><img src="<?php echo base_url(); ?>public/images/liputan/Kompas.png" alt=""></a></div>
            <div class="grid_4"><a href="#"><img src="<?php echo base_url(); ?>public/images//liputan/Liputan6.jpg" alt=""></a></div>
            <div class="clear"></div>
            <div class="grid_4"><a href="#"><img src="<?php echo base_url(); ?>public/images/liputan/Okezone.png" alt=""></a></div>
            <div class="grid_4"><a href="#"><img src="<?php echo base_url(); ?>public/images/liputan/Republika.jpg" alt=""></a></div>
            <div class="grid_4"><a href="#"><img src="<?php echo base_url(); ?>public/images/liputan/Tempo.png" alt=""></a></div>
        </div>
        <div class="clear"></div>
        <div class="grid_12">
            <h3><span>Board Of Advisor</span></h3></div>
        <div class="grid_6">
            <blockquote>
                <img src="<?php echo base_url(); ?>public/images/advisor/RanggaWidigda.jpg" alt="" class="img_inner fleft hvr-bob" style="width: 200px; height: 200px;">
                <div class="extra_wrapper">
                    <p></p>
                    <span class="col2 upp">Rangga Widigda</span>
                </div>
            </blockquote>
        </div>
        <div class="grid_6">
            <blockquote>
                <img src="<?php echo base_url(); ?>public/images/advisor/DamianAgataYuvens.jpg" alt="" class="img_inner fleft hvr-bob" style="width: 200px; height: 200px">
                <div class="extra_wrapper">
                    <p></p>
                    <span class="col2 upp">Damian Agata Yuvens</span>
                    
                </div>
            </blockquote>
        </div>


    </div>
</div>