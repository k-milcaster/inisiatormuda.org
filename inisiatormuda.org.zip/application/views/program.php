<div class="content"><div class="ic"></div>
    <div class="container_12">
        <div class="grid_12">
            <h3><span>Our Portfolio</span></h3>
        </div>
        <div class="clear"></div>
        <div class="port">
            <div class="grid_4">
                <a href="public/images/big2.jpg" class="gal"><img src="public/images/page1_img1.jpg" alt=""></a>
                <div class="text1 col1">Dgtyer tomay</div>
                Syrmentum nisl tempus cometumyloterna to. <br>
                <a href="#">Go to Site</a>
            </div>
            <div class="grid_4">
                <a href="public/images/big2.jpg" class="gal"><img src="public/images/page1_img1.jpg" alt=""></a>
                <div class="text1 col1">Dgtyer tomay</div>
                Syrmentum nisl tempus cometumyloterna to. <br>
                <a href="#">Go to Site</a>
            </div>
            <div class="grid_4">
                <a href="public/images/big2.jpg" class="gal"><img src="public/images/page1_img1.jpg" alt=""></a>
                <div class="text1 col1">Dgtyer tomay</div>
                Syrmentum nisl tempus cometumyloterna to. <br>
                <a href="#">Go to Site</a>
            </div>
            <div class="clear"></div>
            <div class="grid_4">
                <a href="public/images/big2.jpg" class="gal"><img src="public/images/page1_img1.jpg" alt=""></a>
                <div class="text1 col1">Dgtyer tomay</div>
                Syrmentum nisl tempus cometumyloterna to. <br>
                <a href="#">Go to Site</a>
            </div>
            <div class="grid_4">
                <a href="public/images/big2.jpg" class="gal"><img src="public/images/page1_img1.jpg" alt=""></a>
                <div class="text1 col1">Dgtyer tomay</div>
                Syrmentum nisl tempus cometumyloterna to. <br>
                <a href="#">Go to Site</a>
            </div>
            <div class="grid_4">
                <a href="public/images/big2.jpg" class="gal"><img src="public/images/page1_img1.jpg" alt=""></a>
                <div class="text1 col1">Dgtyer tomay</div>
                Syrmentum nisl tempus cometumyloterna to. <br>
                <a href="#">Go to Site</a>
            </div>
            <div class="clear"></div>
            <div class="grid_4">
                <a href="public/images/big2.jpg" class="gal"><img src="public/images/page1_img1.jpg" alt=""></a>
                <div class="text1 col1">Dgtyer tomay</div>
                Syrmentum nisl tempus cometumyloterna to. <br>
                <a href="#">Go to Site</a>
            </div>
            <div class="grid_4">
                <a href="public/images/big2.jpg" class="gal"><img src="public/images/page1_img1.jpg" alt=""></a>
                <div class="text1 col1">Dgtyer tomay</div>
                Syrmentum nisl tempus cometumyloterna to. <br>
                <a href="#">Go to Site</a>
            </div>
            <div class="grid_4">
                <a href="public/images/big2.jpg" class="gal"><img src="public/images/page1_img1.jpg" alt=""></a>
                <div class="text1 col1">Dgtyer tomay</div>
                Syrmentum nisl tempus cometumyloterna to. <br>
                <a href="#">Go to Site</a>
            </div>
        </div>
    </div>
</div>